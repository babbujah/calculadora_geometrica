#include "controlador.h"
#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char* argv[]){

    Controlador control( argv, argc );

    return 0;

}