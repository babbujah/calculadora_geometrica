var searchData=
[
  ['calculadora_5fgeometrica',['calculadora_geometrica',['../d0/d30/md_README.html',1,'']]]
];
