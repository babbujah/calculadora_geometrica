var searchData=
[
  ['paralelepipedo',['Paralelepipedo',['../db/d84/classParalelepipedo.html',1,'']]],
  ['piramide',['Piramide',['../dc/d77/classPiramide.html',1,'']]]
];
