
#include "triangulo.h"
#include "retangulo.h"
#include "circulo.h"
#include "piramide.h"
#include "cubo.h"
#include "paralelepipedo.h"
#include "esfera.h"

using std::cout;

int main(int argc, char* argv[]){

    Piramide piramide(new Retangulo(2,2), new Triangulo(2,3));

    Cubo cubo(new Retangulo(3,3));

    Paralelepipedo par(3, 4, 3);

    Esfera esf( 4 );

    Retangulo ret1( 3, 4 );
    Retangulo ret2( 3 );
    cout << piramide;
    cout << cubo;

    cout << par;

    cout << esf;

    cout << ret1;
    cout << ret2;

    return 0;
}